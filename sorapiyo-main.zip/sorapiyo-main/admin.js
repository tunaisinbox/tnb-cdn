(function () {
  'use strict';
  var hk = (typeof SITE_CONFIG !== 'undefined' && SITE_CONFIG.hitokoto) || {};
  var useApi = !!hk.api;
  var MAX_HISTORY = 10;
  var data = { text: '', updatedAt: null, history: [] };
  var $ = function (id) { return document.getElementById(id); };
  var z = function (n) { return String(n).padStart(2, '0'); };
  function fmt(iso) {
    var d = new Date(iso);
    if (!iso || isNaN(d)) return '';
    return d.getFullYear() + '/' + z(d.getMonth() + 1) + '/' + z(d.getDate()) + ' ' + z(d.getHours()) + ':' + z(d.getMinutes());
  }
  function say(msg, cls) { $('status').className = 'status ' + (cls || ''); $('status').textContent = msg; }

  $('modeBadge').textContent = useApi ? '即時更新モード' : 'ファイル方式';
  $('pwField').hidden = !useApi;
  $('note').textContent = useApi
    ? '「更新する」を押すとすぐにサイトへ反映されます。'
    : '「更新する」を押すと新しい hitokoto.json がダウンロードされます。サイトのファイルに上書きして再アップロードすると反映されます。';
  $('text').addEventListener('input', function () { $('count').textContent = $('text').value.length + ' / 120'; });

  function render() {
    $('current').textContent = data.updatedAt ? '最終更新: ' + fmt(data.updatedAt) : '';
    var pv = $('preview');
    pv.textContent = data.text || '（まだ一言がありません）';
    if (data.updatedAt) {
      var s = document.createElement('small');
      s.textContent = '更新: ' + fmt(data.updatedAt);
      pv.appendChild(s);
    }
    var ul = $('history');
    ul.textContent = '';
    if (!data.history.length) {
      var e = document.createElement('li');
      e.textContent = 'まだありません';
      ul.appendChild(e);
    }
    data.history.forEach(function (h, i) {
      var li = document.createElement('li');
      var box = document.createElement('div');
      box.appendChild(document.createTextNode(h.text));
      var small = document.createElement('small');
      small.textContent = fmt(h.at);
      box.appendChild(small);
      var del = document.createElement('button');
      del.type = 'button';
      del.className = 'ghost';
      del.textContent = '削除';
      del.addEventListener('click', function () { removeHistory(i); });
      li.appendChild(box);
      li.appendChild(del);
      ul.appendChild(li);
    });
  }

  function load() {
    var url = useApi ? hk.api : (hk.file || 'hitokoto.json') + '?t=' + Date.now();
    fetch(url, { cache: 'no-store' })
      .then(function (r) { if (!r.ok) throw new Error(r.status); return r.json(); })
      .then(function (j) {
        data = { text: j.text || '', updatedAt: j.updatedAt || null, history: Array.isArray(j.history) ? j.history : [] };
        $('text').value = data.text;
        $('count').textContent = data.text.length + ' / 120';
      })
      .catch(function () { say('現在の一言を読み込めませんでした（新規として扱います）', 'info'); })
      .then(render);
  }

  function persist() {
    if (useApi) {
      var pw = $('pw').value;
      if (!pw) return Promise.reject(new Error('パスワードを入力してください'));
      return fetch(hk.api, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + pw },
        body: JSON.stringify(data)
      }).then(function (r) {
        if (r.status === 401) throw new Error('パスワードが違います');
        if (r.status === 429) throw new Error('試行回数が多すぎます。しばらく待ってね');
        if (!r.ok) throw new Error('保存に失敗しました (' + r.status + ')');
        return '更新しました。サイトに反映されています。';
      });
    }
    var blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    var a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = 'hitokoto.json';
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(function () { URL.revokeObjectURL(a.href); }, 1000);
    return Promise.resolve('hitokoto.json をダウンロードしました。サイトに上書きしてください。');
  }

  function run(mutate) {
    var backup = JSON.stringify(data);
    $('save').disabled = true;
    say('処理中…', 'info');
    mutate();
    persist().then(function (msg) { render(); say(msg, 'ok'); })
      .catch(function (e) { data = JSON.parse(backup); render(); say(e.message || 'エラーが発生しました', 'err'); })
      .then(function () { $('save').disabled = false; });
  }

  $('save').addEventListener('click', function () {
    var text = $('text').value.trim();
    if (!text) return say('一言を入力してください', 'err');
    if (text === data.text) return say('いまの一言と同じです', 'err');
    run(function () {
      if (data.text) data.history.unshift({ text: data.text, at: data.updatedAt || new Date().toISOString() });
      data.history = data.history.slice(0, MAX_HISTORY);
      data.text = text;
      data.updatedAt = new Date().toISOString();
    });
  });

  function removeHistory(i) {
    if (!confirm('この履歴を削除しますか？')) return;
    run(function () { data.history.splice(i, 1); });
  }

  load();
})();
