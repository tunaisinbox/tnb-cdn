/* 設定ファイル（公開してOKな内容だけ書く） */
var SITE_CONFIG = {
  hitokoto: {
    // Cloudflare Worker のURL（worker.js をデプロイして、そのURLをここに入れる）。
    // 空のままだと hitokoto.json の静的ファイル方式になる
    api: "https://hitokoto.n4v7h5dv5g.workers.dev/",
    file: "hitokoto.json",
    fallback: "エラー"
  }
};
